<?php
$host = "localhost"; // Nama hostnya
$username = "u1578105_simbayar"; // Username
$password = "Tuing13@"; // Password (Isi jika menggunakan password)
$database = "u1578105_datasimbayar"; // Nama databasenya
$koneksi = mysqli_connect($host, $username, $password, $database); // Koneksi ke MySQL
?>
