<div class="container">
    <div class="copyright">
      &copy; Copyright <strong><span style="color: #fff;">Rempahtour</span></strong>. All Rights Reserved
    </div>
</div>