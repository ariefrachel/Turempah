<section id="herb-list" class="herb-list" style="background-color: #fff;">
    <div class="container" data-aos="fade-up">
      <div class="section-header">
        <div class="d-flex justify-content-between">
          <h1 data-aos="fade-up">Tentang kami</h1>

        </div>

      </div>
      <div class="tab-content" data-aos="fade-up" data-aos-delay="300" style="margin-top: 56px;">

        <div class="tab-pane fade active show" id="herb-tabs">

          <div class="row gy-5">
            <div class="col-lg-3 herb-item" data-aos="zoom-in">
              <p style="font-style: italic;">INI PROFIL</p>
            </div>

 
          </div>
        </div>

      </div>

    </div>
  </section>